# GraphCMS Headless Blog
### [Live Site](https://nextjs-plum-five-51.vercel.app/)

![GraphCMS Headless Blog](https://i.ibb.co/NmnJnKD/image.png)

## Stay up to date with new projects
New major projects coming soon, subscribe to the mailing list to stay up to date https://resource.jsmasterypro.com/newsletter

## Introduction
This is a code repository for the corresponding video tutorial. 

With featured and recent posts, categories. full markdown articles, author information, comments, and much more, this fully responsive CMS Blog App is the best Blog Application that you can currently find on YouTube. And what's best of all is that you and your clients can manage the blog from a dedicated Content Management System.

You'll also learn how to work with GraphCMS. GraphCMS is a headless content management system based on GraphQL technology enabling seamless integration with any application.
